fruits = ["orange", 'cherry', "kiwi"]
for index, fruit in enumerate(fruits):
    print(index, fruit)


#enumerate with start value change
for index, fruit in enumerate(fruits, start = 1):
    print(index, fruit)

#enumerate with strings
word = "python"
for i, ch in enumerate(word, start=2):
    print(i,ch)

#enumerate with tuples
fruits = ("orange", 89, "kiwi")
for index, fruit in enumerate(fruits):
    print(index, fruit)

#real time senario

test_cases = ["login, Signup", "checkout"]
for case_no, test in enumerate(test_cases, start=1):
    print (f"Executing test_case {case_no}: {test}")

#accessing of the enumerate values

a = ['God', 'is', 'Great']
b= enumerate(a)
nxt_val = next(b)
nxt_val = next(b)
next_val = next(b)

print(nxt_val)


#duplicate detection using enumerator

characters = ["Krillin", "ram", "rani", "devi",
              "piccolo", "vegeta", "ram", "rani",
              "Goku","Goku", "devi", "vegeta"]
character_map = {character: [] for character in set(characters)}
for index, character in enumerate(characters):
    character_map[character].append(index)
print(character_map)

# practice 1
print(list(enumerate(['a', 'b', 'c'])))


#practice 2
for i, v in enumerate([10,20,30]):
    print(i,v)
#practice 3
colors=['red', 'green', 'blue']
for i, v in enumerate(colors, start =1):
    print(i,v)

#practice 4
print(list(enumerate("PYTHON", start=1)))

#practice 5
nums = [10, 20, 30, 40, 50, 60]
for i, v in enumerate(nums):
    if v == 50:
        print (i)

#practice 6
for i, n in enumerate(range(10, 60, 10)):
    print(i, n)

#practice 7
data=['red', 'green', 'blue']
for i in range(len(data)):
    print(i, data[i])

#practice 8
items = ['a', 'b', 'c']
for i in enumerate(items):
    print(i)

#practice 9
print(list(enumerate([], start=5)))

#practice 10
for i, v in enumerate([100, 200, 300], start=-1):
    print(i, v)

#practice 11
for i, v in enumerate(['x', 'y', 'z']):
    print(i,v)

#practice 12
data= ('a','b','c')
print(list(enumerate(data)))
print(list(enumerate(data, start =1)))