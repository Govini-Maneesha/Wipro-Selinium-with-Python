#CREATE A STUDENT ID SET
studentid = {112, 113, 114, 115,113}
print(studentid)

letters = {'a', 'b', 'c', 'd','e'}
print(letters)
letter = {'a', 'b', 'g', 'p','e'}
print(letter)
#create a mixed set
mixed_set={12, "Java", True,56.5,-4 }
print(mixed_set)

empty_set=set()

#add()
letters.add('f')
print(letters)

#copy
letters.copy()
print(letters)

#difference

print(letters.difference(letter))

#difference update
print(letters.symmetric_difference_update(letter))

#discard
letters.discard('p')
print(letters)

#intersection
print(letters.intersection(letter))
#intersection_update
print(letters.intersection_update(letter))
#isdisjoint
print(letters.isdisjoint(letter))

print(letters.issubset(letter))

print(letters.issuperset(letter))
set1={1,2,4,5}
set2= {3,5,2,7}
print(set1.union(set2))

print(set2.pop())

print(set1.remove(2))

