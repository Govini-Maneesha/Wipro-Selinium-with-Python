"""# fetch the values at the index
a = range(5)
print (a[1])
print(a[3])
a1 = range(2,5)
print (a1[1])

#for loop
a = range(2,5)
for i in a:
    print (i)

a = range(2,5,3)
for i in a:
    print (i)

a = range(2,-15, -3)
for i in a:
    print (i)

# rule: all numbers should be integers
# senario
for attempt in range(3):
    pin = input("Enter the pin: ")
    if pin == "1234":
        print("Access granted")
        break
    else:
        print ("Try Again")

#sinario: Apply discount based on the position(index)
prices = [100, 200, 300, 400]
for i in range(len(prices)):
    if i % 2 == 0:
        print("Discount applied on item {2}")

# senario
import time
for second in range(10):
    print("Checking the status at {second} sec")
    time.sleep(1)
"""
#senario 1
def check_range(num, start, end):
    if start <= num <= end:
        return "Number is within the range"
    else:
        return "Number is not within the range"
print(check_range(10, 5, 15))

# 2
def print_even():
    for i in range(1,51):
        if i % 2 == 0:
            print (i)
print_even()

#3
def sum_numbers():
    total = 0
    for i in range(1,101):
        return total
print(sum_numbers())

#4

for i in range(1, 101):
    if i % 5 ==0:
        print (i)

# 5
numbers = list(range(50,101, 5))
print (numbers)

# 6

for i in range (1, 11):
    print(i * i)

#If you still face any lab challenges or connectivity issues, please write to itsupport@iiht.com including sanjeed.nawaz@techademy.com and rohith.k@techademy.com  as CC members, and provide a screenshot of the error and login details
