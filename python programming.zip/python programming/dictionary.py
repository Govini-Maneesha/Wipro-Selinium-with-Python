#dictionary items - key values
#similar to list and tuples
#for integers, tuples, and strings - keys must be immutable
#list cannot be used in the key for the dictionary as it is mutable in nature
country = {

    "India": "Delhi",
    "Canada": "Ottawa",
    "England": "London"
}
print (country["Canada"])

#add elements
country["Italy"]= "Rome"
print (country)
#delete country
del country["India"]
print (country)
#clear
#country.clear()
#print (country)

#iterate among the dict
for coun in country:
    print(coun)

#len of dictionary
print(len(country))

#pop
country.pop("Canada")
print (country)

#update()
country.update()
print (country)
 #keys
 #values
 #copy- returns the copy of dict
country.copy()
print (country)
 #popitem()- returns the last inserted keyword
country.popitem()
print (country)
# for integers, tuples and strings - keys musgt be immutable
# integer as key

my_dict = {1: "one", 2:"two", 3:"three"}
print(my_dict)

my_dict = {1: "one", 2:"two", 3:"three",  1: "four"}
print(my_dict)

#tuples as a key

my_dict = {(1, 2): "one two", 3:"three"}
print(my_dict)

my_dict = {(1, 2): "one two", 3:"three", 3:"four"}
print(my_dict)

# dictionary inside the list
employee=[
     {"id": 1, "name":"Harsha", "role":"QA"},
     {"id": 2, "name":"Harish", "role":"Dev"},
     {"id": 3, "name":"varsha", "role":"Manager"}
     ]
print(employee[1])
print(employee[0])
print(employee[1]["name"])

for emp in employee:
    print(emp["name"], emp["role"])

employee.append({"id": 4, "name":"mani", "role":"TL"})
print(employee)

employee.pop(0)
print(employee)
#search a item in the list
for emp in employee:
    if emp["name"]=="mani":
        print(emp)
