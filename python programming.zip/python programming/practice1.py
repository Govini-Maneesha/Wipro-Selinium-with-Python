#practice 1
number = [10,20,30,40,80,90,150]
#largest = max(numbers)
#print("Largest number is: ", largest)

largest =number[0]
for num in number:
    if num >largest:
        largest = num

print("Largest number is: ", largest)
#practice 2
numbers1 = [10,20,30,40,80,90,150,3,7,15,25,17]
for num in numbers1[:]:
    if num %2 == 0:
        numbers1.remove(num)
print(numbers1)
#practice 3
numbers = [10,20,30,40,80,90,150,3,7,15,25,17]
for i in numbers[:]:
    print(i*i)