#regular expressions used for searching,matching,manipulating the strings based on specific patterns
#handled using built_in re module
#re.search,re.match

#match the exact sequence
#only matches the starting elements of string not work for "world" in "hello world string
#o/p match object - matched sequence ans span()-start and end index
import re
text="hello world"
result=re.match("hello",text)
print(result)

#using pattern

test_str="123456789abcdefgabc"
pattern = re.compile("abc")

#re.finditer() find all non-overlapping matches of a pattern in a string and
#return an iterator of match objects(not a list)
matches=pattern.finditer(test_str)
for match in matches:
    print(match)

#search operator= searches the entire string
#and returns the first occurance
text ="python is powerful among powerful"
result=re.search("powerful",text)
print(result)

#search function - it searches the entire string but returns only first occurence in the string if it contains two same words
#match- beggining only - used to validate the formates
#finditr()-find all substrings where the RE matches, and returns them as an iterator
#findall()- find all the strings where the re matchs and returns a list

#raw strings- for including special characters

a=r"\thello"
print(a)

#findall
my_string="123dfghhj123a"
pattern=re.compile(r"123")
matches = pattern.findall(my_string)
for match in matches:
    print(match)

#methods as match
#group()-returns the string matched by thr RE
#start()-return the strating position of the match
#end():return the ending position  of the match
#span()-return a tuple containg the (start,end) positions if the match

test_string='123fdfghjk123ABC'
pattern=re.compile(r'123')
matches = pattern.finditer(test_string)
for match in matches:
    print(match)
    print(match.span(),match.start(),match.end())
    print(match.group())#returns the substring that was matched by the RE

    #special charecters
    #meta characters
    #regular expressions

    #pattern meaning
    #abc matches exact text
    #[abc] aor bor c
    #[a-z] lowercase letters
    #a b
    # any single character
text="i like abc and ABCDEFGHIJ"
result = re.findall("[a-z]",text)
print(result)

#[0-9]
text = "i like abc and 123456ABCDEFGHIJ"
result = re.findall("[0-9]",text)
print(result)

text = "cat bat rat"
result = re.findall("cat",text)
print(result)

''' 
Special sequences begin with a backslash.
Sequence    Meaning    Example
#\d  Digit (0–9) \d\d
\D  Non-digit  \D
\w  Word char (a-z, A-Z, 0-9, _)   \w+
\W  Non-word char  \W
\s  Whitespace \s
\S  Non-whitespace \S
\b  Word boundary  \bcat\b
\B  Not a word boundary    \Bcat
'''

#\d Digit (0-9)\d\d
print(re.findall(r"\d","Order 123 costs 450"))
#\D Non-Digit \D
print(re.findall(r"\D","Order 123 costs 450"))
#\w word char(a-z,A-Z,0-9,_) \w+
text="Python_3 version!"
result=re.findall(r"\w",text)
print(result)
#\W  Non-word char  \W
text="Hello@123"
result=re.findall(r"\W",text)
print(result)
#\s  Whitespace \s
text="Helloworld\nPython"
result=re.findall(r"\s",text)
print(result)
#\S  Non-whitespace \S
text="Hello there"
result=re.findall(r"\S",text)
print(result)
#\b  Word boundary  \bcat\b
text="cat scatter catalog"
result=re.findall(r"\bcat\b",text)
print(result)
#\B  Not a word boundary    \Bcat-Matches when pattern is Not at word boundart
text="cat scatter catalog"
result=re.findall(r"cat\B",text)
print(result)

'''Meta-characters have special meaning in regex.

Meta-character  Meaning
.   Any character
^   Start of string
$   End of string
*   0 or more
+   1 or more
?   0 or 1
{n} Exactly n times
{n,}    n or more
{n,m}   Between n and m
[]  Character set
()  Grouping
'''

#start of string
text="python is easy"
print(re.findall(r"python",text))

#end of string
text="python is easy"
print(re.findall(r"easy$",text))

#0 or more
text="ab abb aabb a n"
print(re.findall(r"ab*",text))

#1 or more
text="ab abb aabb a n"
print(re.findall(r"ab+",text))

#0 or 1
text="color colour colr"
print(re.findall(r"colou?r",text))

#{n} exactly n times
text="111 22 3333 668554"
print(re.findall(r"\d{3}",text))

#{n,}  n or more times
text="111 22 3333 668554"
print(re.findall(r"\d{3,}",text))

#{n,m} btw n &m
text="111 22 3333 668554"
print(re.findall(r"\d{2,3}",text))

#[] charset
text="apple banana cat"
print(re.findall(r"[abc]",text))

#()grouping
text="111 22 3333 668554"
print(re.findall(r"\d{3}",text))



'''
Modifier    Short  Purpose
re.IGNORECASE   re.I   Case-insensitive matching
re.MULTILINE    re.M   ^ and $ match each line
re.DOTALL   re.S   . matches newline
re.VERBOSE  re.X   Write readable regex with comments
re.ASCII    re.A   ASCII-only matching
re.DEBUG    —  Debug pattern
'''

text="Hello\nWorld"
print(re.search("Hello.*World",text,re.S))
import re
text="Python"
print(re.search("Python",text,re.M))

import re
pattern = re.compile(r"""23456789asdfgh..%&*&98""",re.X)
print(pattern)

print(re.findall(r"\w+",text,re.A))

pattern = re.compile(r"""23456789asdfgh..%&*&98""",re.DEBUG)
print(pattern)


import re
text="python is easy"
print(re.findall(r"Python",text))

text="python is easy"
print(re.findall(r"easy$",text))

text ="cat scatter catalog"
print(re.findall(r"\bcat\b",text))

text ="cat scatter catalog"
print(re.findall(r"cat\B",text))

text ="user1 admin2 test"
print(re.findall(r"\w+(?=\d)",text))

text ="user1 admin test2"
print(re.findall(r"\w+(?!=\d)",text))

text ="price 500"
print(re.findall(r"\w+(<=)\d+",text))

text ="500 300"
print(re.findall(r"\w+(<!=)\d+",text))

import re

print(re.findall(r"\d*", "ab12cd3"))

re.findall(r"^ab", "ab\nabc\nab", re.M)


print(re.findall(r"[A-Z]+", "PyTHon IS Fun"))
print(re.findall(r".+?", "abc"))




