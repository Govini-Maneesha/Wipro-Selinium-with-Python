'''
Write a regex to check if a string contains only digits.
Write a pattern to match a 10-digit mobile number.
Find all lowercase letters in a string.
Extract all uppercase letters from a sentence.
Match a string that starts with "Hello".
Match a string that ends with "world".
Find all words separated by spaces.
Match exactly 5 characters.
Find all occurrences of the word "python" (case-sensitive).
Replace all spaces in a string with underscores.
'''

import re
from re import findall

#1.\d Digit (0-9)\d\d
print(re.findall(r"\d","Order 123 costs 450"))

#2
text="Python 123456789 callme"
pattern=re.compile(r'123456789')
matches = pattern.finditer(text)
for match in matches:
    print(match)

#2
text ="as 8056356383"
result = re.findall("[0-9]",text)
print(result)
#3
text ="asasgASDFGHJK 8056356383"
result = re.findall("[a-z]",text)
print(result)

#4
text="ASDFGHasdfghjk"
result= re.findall("[A-Z]",text)

#5
text ="Hello world"
result = re.match("Hello",text)
print(result)
#6
text ="Hello world"
result = re.compile("world")
matches=result.finditer(text)
for match in matches:
    print(match.end())

#0r 6
text ="Hello world "
result = re.findall(r"\bworld\b",text)
print(result)

#7
text ="Hello world "
result = re.findall(r"\b\w+\b",text)
print(result)
#8
text="111 22 3333 668554"
print(re.findall(r"\d{5}",text))

#9
text="python uses python libraries"
result=re.findall(r"python",text)
print(result)
#10
text="python uses python libraries"
result=re.sub(r"\s","_",text)
print(result)



