#sum all the nums in list method 1
def sum(nums):
    total = 0
    for i in nums:
        total +=i
    return total
print(sum([1,4,6,7,3,9,6]))

#method 2
def sum_list(nums):
    return sum(nums)
print(sum_list([1,4,6,7,3,9,6]))

#find max num method 1
def find_max(a,b,c):
    if a>=b and a>=c:
        return a
    elif b>=a and b>=c:
        return b
    else:
        return c
print(find_max(1,4,6))
#method 2
def max_find(a,b,c):
    return max(a,b,c)
print(find_max(1,4,6))


#practice filenotfound exception handling
try:
    with open("C://Users//HP//PycharmProjects//PythonProject//Python advance programing//selenium with python//LabSessions//file formates//nestjson.json", "r") as file :
        data = json.load(file)
        print(data)
except FileNotFoundError:
    (print("File not found, provide the correct address"))

#practice invalid user input exception handling
try:
    a=int (input("Enter ur age"))
    if a <=18 :
        print("Invalid user input")
    else:
        print("Age is accepted: ",a)
except ValueError:
    print("invalid user input")

#practice random.choice()
import random
import string
random_char=random.choice(string.ascii_letters)
print("Random Alphabet Charecter:",random_char)

length= random.randint(5,10)
random_string =''.join(random.choice(string.ascii_letters)for _ in range(length))
print("random alpha strings:",random_string)

fixed_length = 5
fixed_string=''.join(random.choice(string.ascii_letters)for _ in range(fixed_length))
print("fixed len strings:",fixed_string)

#iterator prac 1
a=int(input("enter nums"))
#convert the list into a iterator
iterator = iter(range(1, a+1))

 #next( allow the user to access the elements
for num in iterator:
    print(num)

#prac 2
class EvenIterator:
    def __init__(self):
        self.num = 0

    def __iter__(self):
        return self

    def __next__(self):
        self.num += 2
        return self.num
evens = EvenIterator()
for _ in range(5):
    print(next(evens))




