#generatore are a special type of functions which will return one value at a time, on demand
#yield funtion is only used in generator only
#used= 1.memory efficient
#2.useful for large set of data
#3. files, retries, batching

#normal functions
def numbers():
    return[1,2,3,4]
print(numbers())
#normal function loads all values into memory

#generator
def generator():
    print("printing 1")
    yield 1
    print("printing 2")
    yield 2
    print("printing 3")
    yield 3
    print("printing 4")
    yield 4

ret_value=generator()
print(next(ret_value))
print(next(ret_value))
print(next(ret_value))
print(next(ret_value))

#peac 1
def numbers_upto_n(n):
    for i in range(1, n+1):
        yield i
for num in numbers_upto_n(5):
    print(num)

#prac2
def even_numbers(n):
    for i in range(2, n+1, 2):
        yield i
for num in even_numbers(10):
    print(num)

#prac3
def read_file(filename):
    with open(filename,"r")as f:
        for line in f:
            yield line
for line in read_file("C://Users//HP//PycharmProjects//PythonProject//Python advance programing//selenium with python//LabSessions//file formates//data.csv"):
    print(line.strip())
#prac 4
def fibonacci(n):
    a, b = 0, 1
    for _ in range(n):
        yield a
        a, b = b, a + b
for num in fibonacci(10):
    print(num)

#prac 5
def retry():
    for attempt in range(1,4):
        yield attempt
correct_password="1234"
for attempt in retry():
    pwd=input(f"Attempt{attempt}: enter pass:")
    if pwd== correct_password:
        print("login successfull")
        break
    else:
        print("Maximum attempts reached")
