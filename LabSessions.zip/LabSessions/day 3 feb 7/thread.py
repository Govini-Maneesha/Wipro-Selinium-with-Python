#threading - execution of tasks
#multi threading - execution of many tasks at atime -- concurrent execution
#multiprocessing-
#threading - imported
#process - Execution unit
#threads - light weight unit inside the process

#simple thread
import threading
import time

def task ():
    print("thread started")
    time.sleep(2)
    print("Threading finished")

t= threading.Thread(target = task)
t.start()
t.join()

print("Thread terminated")