#exceptions - runtime errors which will discupt the normal program flow
#benifits--
#helps in debugging
#prevents programe crashing
#handling errors and exceptions in the code more efficiently

#try, except-->
#try - code to be executed
#exept - exceptions details catching

#else: if the exception dosnot occure then else part will be executed
#finally - mandated code --> even if exceptions occure or nor occure finnaly code will run
#custum exceptions

try:
    a=int (input("Enter the number"))
    b=int (input("Enter the number"))
    print(a/b)
except ZeroDivisionError:
    print("Cannot divisible zero")
except ValueError:
    print("Please enter valid number")

#generic exception
try:
    a=5/10
except Exception as e:
    print(e)

#runs only if no exceptions occurs
else:
    print("Division sucessful")

#mandatory code
finally:
    print("Close the browser")

#custom exceptions --> creating our own exceptions
age = int(input("enter the age"))
if age < 18:
    raise ValueError("Age must be greaterthan 18 or above")


