#subprocess modules
#executes external system commands
#iteract with os processors
#capture output, error and return codes
#control the process excecution

#run the os level commands- linux, macos, windows

import subprocess
#subprocess.run()--> run command and wait
#subprocess.popen()--> run process asynchronously
##subprocess.PTPE-->capture the output
#subprocess.CompleteProcess--> result
#subprocess.TimeoutExpired--> time out exception
#subprocess.CalledProcessError-command failure

result = subprocess.run("dir",shell=True, capture_output=True, text=True)
print(result)
result = subprocess.run("ipconfig",shell=True, capture_output=True, text=True)
print(result)
result = subprocess.run("python --version",shell=True, capture_output=True, text=True)
print(result)
print(result.stdout)
print(result.stderr)