import csv
#read
with open("C://Users//HP//PycharmProjects//PythonProject//Python advance programing//selenium with python//LabSessions//file formates//data.csv", "r") as file:
    reader = csv.reader(file)
    for row in reader:
        print(row)
#write
with open("C://Users//HP//PycharmProjects//PythonProject//Python advance programing//selenium with python//LabSessions//file formates//write.csv", "w",newline="") as file:
    writer = csv.writer(file)
    writer.writerow(["id", "name", "marks"])
    writer.writerow([1, "Rahul", 85])
    writer.writerow([2, "Anita", 90])


#append
with open("C://Users//HP//PycharmProjects//PythonProject//Python advance programing//selenium with python//LabSessions//file formates//write.csv", "a", newline="") as file:
    writer = csv.writer(file)
    writer.writerow([3, "Kiran", 88])
