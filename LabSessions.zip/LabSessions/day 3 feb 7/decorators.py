#decorators --> wraper function around the functions are called as decorator
#decorator
def make_pretty(func):
    def inner():
        print("I got decorated")
        func()
    return inner()
@make_pretty
def venilacake():
    print('I am a vennila cake')

@make_pretty
def strawberrycake():
    print('I am a strawberry cake')

venilacake()
strawberrycake()