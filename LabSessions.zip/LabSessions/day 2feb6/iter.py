#iter( method - built in method
#create a iterator from a iterable
#iterations - looping in the collections of items

a = [ 10,20,30,40,50]
#convert the list into a iterator
iterator = iter(a)

 #next( allow the user to access the elements

print(next(iterator))
print(next(iterator))
print(next(iterator))
print(next(iterator))
print(next(iterator))

#string
s = "hello"
iterator = iter(s)
print(next(iterator))
print(next(iterator))
print(next(iterator))
print(next(iterator))
print(next(iterator))
#convert the dict to a iterator
a={'a': 1, 'b': 2, 'c':3}
iterator=iter(a)
print(next(iterator))
print(next(iterator))
#for loop to iterate
for key in iterator:
    print(key)

it=iter(a.items())
for key, value in a.items():
    print(key,"->", value)
#itr(callable, sentinel)
def get_input():
    return input("Enter value:")
for value in iter(get_input, "quit"):
    print("you entered:",value)
print("loop ended")
 