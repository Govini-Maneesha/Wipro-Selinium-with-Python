list = [20,4,5,89,9,79,23]
sorteddata= sorted(list,key=lambda x:x)
print(sorteddata)

#prac 2
from datetime import date
today = date.today()
getyear = lambda x:x.year
getmonth = lambda x:x.month
getday = lambda x:x.day
print((today))
print(getyear(today))
print(getmonth(today))
print(getday(today))

#prac 3
dict1 = {1:10, 2:20}
dict2 = {3:30, 4:40}
dict3 = {4:40, 5:50}
newdict = {}
newdict.update(dict1)
newdict.update(dict2)
newdict.update(dict3)
print("concatinated dict: ", newdict)

