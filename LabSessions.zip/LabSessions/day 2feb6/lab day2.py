student_info = [{"stu-id": 1 , "name": "Jeni"},
{"stu-id": 2 , "name": "kiran"},
{"stu-id": 3, "name": "pooja"},
{"stu-id": 4 , "name": "nani"},
{"stu-id": 5 , "name": "jaya"}]

print(student_info[1])

for student in student_info:
    if student["stu-id"]==3:
        student["stu-id"] = 6
print(student_info)

#pop
student_info.pop(2)
print(student_info)
#del
del student_info[1]
print(student_info)
#update
student_info[2].update({"stu-id": 6})
print(student_info)

#no.of keys and values
print(len(student_info))

#no.keys
for student in student_info:
    print(student.keys())

#no.values
for student in student_info:
    print(student.values())

#items
for student in student_info:
    print(student.items())