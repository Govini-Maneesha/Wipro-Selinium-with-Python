#Module is a file that contains python coe -var, functionals, classes
#benefits-
#code reusability, easier maintanance
#better organization

#1.builtin modules,2.user defined modules

#built in modules- math, datetime, os,sys,

from datetime import datetime
from datetime import date
import math

print(math.sqrt(19))
print(math.pi*2)

print(datetime.now())
print(date.today())