#java script object notation- JSON
#data always stored in double Quots in object formate
import json
with open("C://Users//HP//PycharmProjects//PythonProject//Python advance programing//selenium with python//LabSessions//file formates//nestedjson.json", "r") as file :
    data = json.load(file)
    print(data)


