import xml.etree.ElementTree as ET

#read xml file
tree=ET.parse("C://Users//HP//PycharmProjects//PythonProject//Python advance programing//selenium with python//LabSessions//file formates//employee.xml")
root=tree.getroot()
print(root.tag)

#fetcgh xml tag values

print(root[0].tag)
print(root[1].tag)

#get attributes of child nodes
print(root[0].attrib)

#fetch all the attributes in the child node
for employee in root.findall("employee"):
    emp_id = employee.get("id")
    print(emp_id)
    emp_name = employee.find("name").text
    print(emp_name)
    emp_role = employee.find("role").text
    print(emp_role)

#root--> child nodes --> atrributes of the child nodes----> text of the attributes
#write the data to xml file
#create the child node

root = ET.Element("employees")


#create the child elements
emp1= ET.SubElement(root,"employee", id = "101")
ET.SubElement(emp1,"name").text ="Harsha"
ET.SubElement(emp1,"role").text ="Tester"
ET.SubElement(emp1,"experience").text ="5"

emp2= ET.SubElement(root,"employee", id = "102")
ET.SubElement(emp2,"name").text ="Amit"
ET.SubElement(emp2,"role").text ="Developer"
ET.SubElement(emp2,"experience").text ="3"
tree.write("employee.xml")
#write to the file

tree= ET.ElementTree(root)
tree.write("C://Users//HP//PycharmProjects//PythonProject//Python advance programing//selenium with python//LabSessions//file formates//writexml.xml",encoding="utf-8", xml_declaration=True)

#update the xml
tree=ET.parse("C://Users//HP//PycharmProjects//PythonProject//Python advance programing//selenium with python//LabSessions//file formates//updatexml.xml")
root = tree.getroot()

for emp in root.findall("employee"):
    if emp.get("id")=="101":
        emp.find("experience").text="16"

tree.write("C://Users//HP//PycharmProjects//PythonProject//Python advance programing//selenium with python//LabSessions//file formates//updatexml.xml",encoding="utf-8", xml_declaration=True)
