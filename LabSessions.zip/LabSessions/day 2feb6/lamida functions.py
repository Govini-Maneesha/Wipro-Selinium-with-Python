#lambda functions- anonymous (nameless) functions, one line, simple operations
#function - function name, arguments, return type,m code
#it can have any number of arguments
#must have only one expression
#the expression is automaticaly return the value
#no return keyword used

#normal function add 2 numbers
def add(a,b):
    return a+b
print(add(5,3))

#lambda function
add = lambda a,b: a+b
print(add(5,3))

#square = lambda

square =lambda x:x*x
print(square(5))
#even / odd

even = lambda x: "even" if x%2==0 else "odd"
print(even(9))

#find max of 2 num
max= lambda a,b: a if a>b else b
print(max(10,58))

#filter, map and reduce in built sunction in lambda
#map_transform the data
#filter- select data- filtering the data
#reduce - aggregate the data

#filter
numbers = [1,2,3,4,5,6]
evens = list(filter(lambda x:x%2==0, numbers))
print((evens))

#filter the failed testcases
status = ['pass', 'fail', 'pass','fail','pass']
failed = list(filter(lambda s:s == 'fail', status))
print((failed))
#filter positive numbers
nums = [-5,10,-3,7,0,2]
positive= list(filter(lambda s:s >0, nums))
print(positive)
#return non empty data
data = ["hello", "", "world", "", "python"]
nonempty= list(filter(lambda s:s!= "" , data))
print(nonempty)

#reduce-aggregatecombining many values to a one single result
from functools import reduce
nums = [10, 20, 50, 60,30]
print(reduce(lambda x,y : x+y, nums))
#mul
mul = [10,2, 5, 6,3]
print(reduce(lambda x,y : x*y, mul))

# max value
print(reduce(lambda x, y: x if x > y else y, nums))
# min value
print(reduce(lambda x, y: x if x < y else y, nums))

#map- transform the data - the functiom is applied to evry element

num = [10,20,30,40]
squares= list(map(lambda x:x*x, num))
print(squares)

#sorting in lambda
data = [(1,3,4), (9,2,8),(6,1,5)]
sorteddata= sorted(data,key=lambda x:x)
print(sorteddata)

marks= {"a": 77, "b": 98, "c": 67}
sortedmarks= dict(sorted(marks.items(),key=lambda x:x[1]))
print(sortedmarks)

#filter
nums = [1, 2, 3, 4, 5, 6]
even= list(filter(lambda x: x%2==0,nums))
print(even)
#map
even= list(map(lambda x: x%2==0,nums))
print(even)

#square
squares= list(map(lambda x:x*x,nums))
print("squares:", squares)
#total
total = reduce(lambda x,y:x+y,squares)
print("total:", (total))

#salaries senario
salaries = [25000, 40000, 32000, 18000]
good_salaries = list(filter(lambda sal: sal > 30000, salaries))
print("salaries above 30,000 are:")
print(good_salaries)

hiked_salaries = list(map(lambda s: s + (s * 0.1), good_salaries))
print("salaries after hike:")
print(hiked_salaries)

total_payout = reduce(lambda x, y: x + y, hiked_salaries)
print("total payout:")
print(total_payout)

#map()-->transform elements,same as input, function type-one-to-one,module-built-in,lambda usage-very common
#reduce()-->combine element, single value, functool as function
nums = [1, 2, 3]

f = map(lambda x: x * 2, nums)

nums.append(4)

print(list(f))

print(list(map(lambda x: x + x, [1, 2, 3])))
