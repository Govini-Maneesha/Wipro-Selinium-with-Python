#comphredions - create lists using a single line of code instead of loops
#syntax
#expression for item in iterable if condition
#square of a num

sqs = [x**2 for x in range (1,6)]
print(sqs)

#with the condition
evennumbers = [x for x in range(10) if x %2 ==0]
print(evennumbers)

#dict comphresion - increase salary by 10%
salary = {"A": 50000, "B": 70000, "C":80000}
update_sal = {k:v+0.1 *v for k,v in salary.items()}
print(update_sal)

employess = {
    "harsha": "active",
    "mitra": "inactive",
    "amith": "active"
}
active_emp = {k:v for k,v in employess.items()if v == "active"}
print(active_emp)


sqs = {x**2 for x in range(1,6)}
print(sqs)


