import requests

try:
    response = requests.get("https://jsonplaceholder.typicode.com/users")
    print(response)

    if response.status_code == 200:
        print("Status code is 200 ok")

        users = response.json()

        for user in users:
            print(user["username"].upper())

    else:
        print(f"Error:Received status code{response.status_code}")

except requests.exceptions.RequestException as e:
    print(f"An error occured: {e}")