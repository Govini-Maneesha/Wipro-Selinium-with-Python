import requests
import json

try:
    response = requests.get("https://jsonplaceholder.typicode.com/posts")
    print(response)

    if response.status_code == 200:
        print("Status code is 200 ok")

        data = response.json()

        with open("posts.json", "w") as file:
            json.dump(data, file, indent=4)

        print("Saved to posts.json")

    else:
        print(f"Error:Received status code{response.status_code}")

except requests.exceptions.RequestException as e:
    print(f"An error occured: {e}")