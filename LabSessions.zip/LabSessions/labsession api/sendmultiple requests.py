import requests

try:
    session = requests.Session()

    session.get("https://httpbin.org/cookies/set/mycookie/123")

    response = session.get("https://httpbin.org/cookies")
    print(response)

    if response.status_code == 200:
        print("Status code is 200 ok")

        data = response.json()
        print(data)

    else:
        print(f"Error:Received status code{response.status_code}")

except requests.exceptions.RequestException as e:
    print(f"An error occured: {e}")