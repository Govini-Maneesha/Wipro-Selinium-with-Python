import requests
import os

try:

    file_path = "sample.txt"

    # check if file exists
    if not os.path.exists(file_path):
        print("Error: sample.txt file not found. Please create the file in your project folder.")
    else:

        with open(file_path, "rb") as file:
            files = {"file": file}

            # make a post request to upload file
            response = requests.post("https://httpbin.org/post", files=files)
            print(response)

            # check if the status code is 200
            if response.status_code == 200:
                print("Status code is 200 ok")

                data = response.json()
                print(data)

            else:
                print(f"Error:Received status code{response.status_code}")

except requests.exceptions.RequestException as e:
    print(f"An error occured: {e}")