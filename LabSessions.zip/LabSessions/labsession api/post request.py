import requests
try:
    data={
    "id": 1,
    "name": "Leanne Graham",
    "username": "Bret",
    "email": "Sincere@april.biz",
    "address": {
      "street": "Kulas Light",
      "suite": "Apt. 556",
      "city": "Gwenborough",
      "zipcode": "92998-3874",
      "geo": {
        "lat": "-37.3159",
        "lng": "81.1496"
      }
    }
     
    }
#make a post request to a api endpoint
    response=requests.post("https://jsonplaceholder.typicode.com/users",json=data)
    print(response)

    # check if the status code is 200
    if response.status_code==200:
        print("Status code is 200 ok")
        # pass the json file
        data=response.json()
        print(data)

    else:print(f"Error:Received status code{response.status_code}")


except requests.exceptions.RequestException as e:
    print(f"An error occured: {e}")