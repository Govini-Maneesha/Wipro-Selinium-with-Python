import requests

try:
    params = {"userId": 2}

    response = requests.get("https://jsonplaceholder.typicode.com/posts", params=params)
    print(response)

    if response.status_code == 200:
        print("Status code is 200 ok")

        data = response.json()
        print("Number of posts:", len(data))

    else:
        print(f"Error:Received status code{response.status_code}")

except requests.exceptions.RequestException as e:
    print(f"An error occured: {e}")