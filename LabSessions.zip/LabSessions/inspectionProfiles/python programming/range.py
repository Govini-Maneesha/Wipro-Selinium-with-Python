#all numbers should be integers
#range doesnot create list it creates object
#step sixe cannot be zero
#stop ending number which is not included
#incement/decrement- default -1
#usage
#1.fast iteration
#2.loops and indexinhg
#3.
a=range(5)
print(a[1])
print(a[3])

a1=range(2,5)
print(a1[1])

#for loop for range of 2 arguments
a=range(2,1)
for i in a:
    print(i)

#for loop for range of 3 arguments
a=range(2,1,9)
for i in a:
    print(i)

#for loop for range of 3 arguments in negative but it doesnot give output
a=range(2,1,-3)
for i in a:
    print(i)

#printing reverse
a=range(2,1,-1)
for i in a:
    print(i)