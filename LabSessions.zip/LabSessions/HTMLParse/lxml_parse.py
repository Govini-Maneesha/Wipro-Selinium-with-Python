import requests

from HTMLParse.BeautifulSoup import response
from lxml import html
url="http://news.ycombimator.com"
response=requests.get(url)

data = html.fromstring(response.content)
title = data.find(".//title").text

print(title)

#links

links= data.xpath("//@href")
print(links)

links=data.xpath("//a")
for link in links:
    print(link.text)
    print(link.get("href"))

titlelines= data.find("//span[@class='titleline']")
print(titlelines)
for title in titlelines:
    print(title.text)


