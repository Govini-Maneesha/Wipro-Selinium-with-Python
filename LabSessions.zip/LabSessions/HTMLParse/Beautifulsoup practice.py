from bs4 import BeautifulSoup
import requests
import urllib3

# Fix SSL warning
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

url = "https://books.toscrape.com/"
response = requests.get(url, verify=False)

soup = BeautifulSoup(response.text, "html.parser")


# 1) Extract title and h1
print("1) Title:", soup.title.text)
h1 = soup.find("h1")
print("1) H1:", h1.text if h1 else None)


# 2) Extract All Paragraphs
print("\n2) Paragraphs:")
for p in soup.find_all("p"):
    print(p.text.strip())


# 3) Extract All Links and Count
links = soup.find_all("a")
print("\n3) Total Links:", len(links))


# 4) Extract Attributes (first image)
img = soup.find("img")
print("\n4) First Image Attributes:", img.attrs if img else None)


# 5) Extract First h2
h2 = soup.find("h2")
print("\n5) First H2:", h2.text if h2 else None)


# 6) Extract Bold Text
b = soup.find("b")
print("\n6) Bold Text:", b.text if b else None)


# 7) Extract All href Values
print("\n7) First 10 href values:")
for link in links[:10]:
    print(link.get("href"))


# 8) Get All Text Without Tags
print("\n8) First 500 Characters Text:")
print(soup.get_text()[:500])


# 9) Extract Title from Website
print("\n9) Website Title:", soup.title.text)


# 10) Extract All Headings
print("\n10) All Headings:")
for tag in soup.find_all(["h1","h2","h3","h4","h5","h6"]):
    print(tag.text.strip())


# 11) Extract Table-type Data (Book Names & Prices)
print("\n11) Books and Prices:")
books = soup.find_all("article", class_="product_pod")
for book in books:
    name = book.h3.a["title"]
    price = book.find("p", class_="price_color").text
    print(name, "-", price)


# 12) Extract Images
print("\n12) Image Sources:")
for image in soup.find_all("img")[:10]:
    print("https://books.toscrape.com/" + image.get("src"))