from bs4 import BeautifulSoup
import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Given HTML
html = """
<html>
<head><title>My Page</title></head>
<body>
<h1>Welcome</h1>
<p>This is a paragraph.</p>
</body>
</html>
"""

soup = BeautifulSoup(html, "html.parser")

# 1) Extract title and h1
print("1) Title:", soup.title.text if soup.title else None)
print("1) H1:", soup.h1.text if soup.h1 else None)


# 2) Extract All Paragraphs
print("\n2) Paragraphs:")
for p in soup.find_all("p"):
    print(p.text)


# 3) Extract All Links and Count
links = soup.find_all("a")
print("\n3) Total Links:", len(links))
for link in links:
    print(link.text)


# 4) Extract Attributes
print("\n4) Image Attributes:")
img = soup.find("img")
print(img.attrs if img else None)


# 5) Extract First h2
h2 = soup.find("h2")
print("\n5) First H2:", h2.text if h2 else None)


# 6) Extract Bold Text
b = soup.find("b")
print("\n6) Bold Text:", b.text if b else None)


# 7) Extract All href Values
print("\n7) All href values:")
for link in links:
    print(link.get("href"))


# 8) Get All Text Without Tags
print("\n8) All Text:")
print(soup.get_text())


# 9) Extract Title from Website
web = requests.get("https://example.com", verify=False)
websoup = BeautifulSoup(web.text, "html.parser")
print("\n9) Website Title:", websoup.title.text)


# 10) Extract All Headings
print("\n10) All Headings:")
for tag in soup.find_all(["h1","h2","h3","h4","h5","h6"]):
    print(tag.text)


# 11) Extract Table Data
print("\n11) Table Data:")
for row in soup.find_all("tr"):
    cols = row.find_all(["td","th"])
    print([col.text for col in cols])


# 12) Extract Images
print("\n12) Image Sources:")
for img in soup.find_all("img"):
    print(img.get("src"))