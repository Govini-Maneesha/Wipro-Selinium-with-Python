class a:
    def show(self):
        print("class a")
class b(a):
    def show(self):
        print("class b")
class c(a):
    def show(self):
        print("class c")

class d(b,c):
    def show(self):
        print("class d")
D=d()
D.show()
print(d.mro())
#method from left to right