#Lab 1: Method Overriding with Inheritance
#Create a base class Employee with a method calculate_salary().
#Create a subclass Manager that overrides calculate_salary() and adds a bonus.
#Demonstrate runtime polymorphism using parent class reference.
class Employee():
    def __init__(self,name,id,salary):
        self.name = name
        self.id = id
        self.salary = salary
    def calculate_salary(self):
        return(self.salary)


class Manager(Employee):
    def calculate_salary(self):
        bonus=5000
        return self.salary + bonus
emp = Employee("Maneesha",4355,40000)
mgr=Manager("Maneesha",4355,40000)

print("Employee salary",emp.calculate_salary())
print("salary with bonus", mgr.calculate_salary())

#Lab 2: Polymorphism Using Function Arguments
#Create classes Dog, Cat, and Cow each with a method speak().
#Write a function animal_sound(obj) that calls speak().
#Pass different objects to the same function.

class Animal:

    def animal_sound(self):
        print("Animal makes sound")


class Dog(Animal):

    def animal_sound(self):
        print("ufff")
class cat(Animal):

    def animal_sound(self):
        print("meoww")
class cow(Animal):

    def animal_sound(self):
        print("bowwww")



a = Dog()
b=cat()
c=cow()
a.animal_sound()
b.animal_sound()
c.animal_sound()

#or
class Dog:

    def speak(self):
        print("ufff")
class cat:

    def speak(self):
        print("meoww")
class cow:

    def speak(self):
        print("bowwww")
def animal_sound(obj):
    obj.speak()

a = Dog()
b=cat()
c=cow()
animal_sound(a)
animal_sound(b)
animal_sound(c)

#Lab 3: Multilevel Inheritance with Polymorphism
#Create Vehicle → Car → ElectricCar.
#Each class overrides the method fuel_type().
#Call the method using different object references.

class vehicle:
    def fuel_type(self):
        print("uses fuel")
class car(vehicle):
    def fuel_type(self):
        print("petrol")

class electriccar(car):
    def fuel_type(self):
        print("electricoity")

a=vehicle()
b=car()
c=electriccar()
a.fuel_type()
b.fuel_type()
c.fuel_type()

'''
Lab 4: Operator Overloading
Create a class BankAccount with attribute balance.
Overload + to add balances and > to compare balances.
Demonstrate polymorphic behavior of operators.
'''
class banck_account:
    def __init__(self,balance):
        self.balance=balance
    def __add__(self, other):
        return self.balance+other.balance
    def __gt__(self, other):
        return self.balance>other.balance

n1=banck_account(10000)
n2=banck_account(900)
print(n1+n2)
print(n1 > n2)

'''Lab 6: Multiple Inheritance and MRO
Create classes A, B, C, and D (diamond structure).
Override the same method in B and C.
Call method using D object and observe MRO.'''

class a:
    def show(self):
        print("class a")
class b(a):
    def show(self):
        print("class b")
class c(a):
    def show(self):
        print("class c")

class d(b,c):
    def show(self):
        print("class d")
D=d()
D.show()
print("mro of d",d.mro())

'''Lab 7: Polymorphism with Exception Handling
Create Calculator class with divide().
Create SafeCalculator that overrides divide() and handles ZeroDivisionError.
Demonstrate method overriding.'''

class calculator:
    def divide(self,num1,num2):
        return num1/num2
class safecalculator(calculator):
    def divide(self, num1,num2):
        try:
            return num1/num2
        except ZeroDivisionError:
            print("number cannot be divided with zero")

n1=calculator()
n2=calculator()
print(n1.divide(9,6))
print(n2.divide(9,10))

'''Lab 8: Real-Time Payment System
Create base class Payment with method pay().
Create CreditCard, UPI, and NetBanking subclasses.
Use a single function to process all payments.'''

class payment:
    def pay(self):
        print("doing payment")
class Creditcard(payment):
    def pay(self):
        print("paying using Creditcard")
class UPI(Creditcard):
    def pay(self):
        print("paying using upi")
class Netbanking(UPI):
    def pay(self):
        print("paying using netbanking")

a=payment()
b=Creditcard()
c=UPI()
d=Netbanking()
a.pay()
b.pay()
c.pay()
d.pay()

#or
class Payment:
    def pay(self, amount):
        raise NotImplementedError("Subclass must implement pay()")

class CreditCard(Payment):
    def pay(self, amount):
        return {amount}

class UPI(Payment):
    def pay(self, amount):
        return {amount}

class NetBanking(Payment):
    def pay(self, amount):
        return {amount}

def process_payment(payment_obj, amount):
    print(payment_obj.pay(amount))

# Demonstration
process_payment(CreditCard(), 1000)
process_payment(UPI(), 500)
process_payment(NetBanking(), 2000)

