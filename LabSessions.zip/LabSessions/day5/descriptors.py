#descriptors-used to attribute access in the objects
#control the access of the object attribution
# _get_()
# _set_()
# _delete_()

class Desc:
    def __get__(self, instance, owner):
        print("getting the value")
        return 10
class test:
    x=Desc()
t=test()
print(t.x)
# this non-data descriptor-uses only __get__descriptor
# data desc uses both get and set methods

class mydesc:
    def __set__(self, instance, value):
        return instance._value
    def __get__(self, instance, owner):
        print("setting input")
        instance._value=value
class test:
    x=mydesc
t=test()
t.x=100
print(t.x)

#delete
class Name:
    def __get__(self, instance, owner):
        return instance._name
    def __set__(self, instance, value):
        instance._name = value

    def __delete__(self, instance):
        print("deleting name")
        del instance._name

class person:
    name =Name()
p=person()
p.name="mani"
del p.name





