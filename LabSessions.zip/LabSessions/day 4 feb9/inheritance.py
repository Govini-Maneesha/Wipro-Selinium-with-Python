#1.single inheritance
#2.multiple inheritance--in this dimond problem is there
#3.multilevel inheritance
#4.heirarcheal inheritance
#hybrid inheritance
from operator import length_hint


class employee:
    def __init__(self,name,empid):
        self.name=name
        self.empid=empid

    def empdetails(self):
        print(self.name,self.empid)
#child class
class Manager(employee):
    def approve_leave(self):
        print("leave approved")
#create object of the child classes to bring inheritance
m=Manager("Vedha",234)
m.empdetails()
m.approve_leave()


#prac1
class savingsaccount:
    def __init__(self,accno,holdername,amount):
        self.accno=accno
        self.holdername=holdername
        self.amount=amount
        print("current amount", amount)
    def deposit(self,deposit_amount):
        self.amount += deposit_amount
        print("Deposited amount",deposit_amount)

class account(savingsaccount):
    def addintrest(self):
        self.intrest=self.amount+0.1*self.amount-self.amount
        print("intrests",self.intrest)
        print("total",self.amount+ self.intrest)


a=account(12345,"Maneesha",20000)
a.deposit(5000)
a.addintrest()

#multilevel
class employee:
    def __init__(self,name,empid):
        self.name=name
        self.empid=empid

    def empdetails(self):
        print(self.name,self.empid)
#child class
class HR(employee):
    def leaveapplication(self):
        print("leave application submited")
        #child class
class Manager(HR):
    def approve_leave(self):
        print("Leave approved")
#create object of the child classes to bring inheritance
m=Manager("Vedha",234)
m.empdetails()
m.leaveapplication()
m.approve_leave()


#heirarcheal inheritance

class employee:
    def login(self):
        print("Employee is logged in")

class Developer(employee):
    def write_code(self):
        print("writting code")
class tester(employee):
    def test_app(self):
        print("Testing the application")
dev=Developer()
test=tester()
dev.write_code()
test.test_app()

#multiple inheritance-- 2 parents one child
class Father:
    def driving(self):
        print("father has the driving skill")
class Mother:
    def cooking(self):
        print("mother has cooking skills")

class child(Father,Mother):
    def bothskills(self):
        print("skill to study")
        print("both skills from parents")
skill=child()
skill.bothskills()
skill.driving()
skill.cooking()


class parent1:
    pass
class parent2:
    pass
class child(parent1,parent2):
    pass

#1.Write a Python program to create a class representing a Circle. Include methods to calculate its area and perimeter
class circle:
    def __init__(self,length,width):
        self.length=length
        self.width=width
class area(circle):
    def calculatearea(self):
        area=self.length * self.width
        print("area of circle:",area)
class perimeter(area):
    def calculateperimeter(self):
        perimeter=2*(self.length +self.width)
        print("perimeter of circle:",perimeter)

cal=perimeter(5,8)
cal.calculatearea()
cal.calculateperimeter()

#2.Write a Python program to create a person class. Include attributes like name, country and date of birth. Implement a method to determine the person's age.
from datetime import date
class person:
    def __init__(self,name,country,birth_date,birth_month,birth_year):
        self.name=name
        self.country= country
        self.birth_date=birth_date
        self.birth_month=birth_month
        self.birth_year=birth_year

    def person_age(self):
        today=date.today()
        age=today.year-self.birth_year
        print("NAme:",self.name)
        print("COUNTRY:",self.country)
        print("Age:",age)

p=person("Maneesha","India",20,7,2004)
p.person_age()

#3.Write a Python program to create a class that represents a shape. Include methods to calculate its area and perimeter. Implement subclasses for different shapes like circle, triangle, and square.
class shape:
    def area(self):
        pass
    def perimeter(self):
        pass
class circle(shape):
    def __init__(self,radious):
        self.radious=radious
    def area(self):
        print("circle area=", 3.14 * self.radious *self.radious)
    def perimeter(self):
        print("circle perimeter=", 2*3.14 * self.radious)

class square(shape):
    def __init__(self,side):
        self.side=side
    def area(self):
        print("square area",self.side*self.side)
    def perimeter(self):
        print("square perimeter",4*self.side)
class triangle(shape):
    def __init__(self,a,b,c):
        self.a=a
        self.b=b
        self.c=c
    def area(self):
        print("triangle area",self.a * self.b*self.c)
    def perimeter(self):
        print("triangle perimeter", self.a + self.b + self.c)

c=circle(5)
c.area()
c.perimeter()
s=square(4)
s.area()
s.perimeter()
t=triangle(4,4,4)
t.area()
t.perimeter()

#4.Write a python program to create a child class Bus that will inherit all of the variables and methods of the Vehicle class
#5.Write a python program to create  a Vehicle class without any variables and methods



