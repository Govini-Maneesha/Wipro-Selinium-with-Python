# destructors - when we want to destroy the object
# post conditions - closing of the browser , db connection closing, releasing of certain resources
# clean up operations
# for proper memory usage destructors should be used
# when db connection has to be closed
# free the memory (gargabe collection) which is automatically called

class desct:
    def __init__(self):
        print("object created")

    def __del__(self):
        print("closing the db connection")

a=desct()
print("end of the program")
del a

#desct in file handling
class filehandling:
    def __init__(self,filename):
        self.file=open(filename, 'w')
        print("file is opened")

    def readfile(self,filename):
        print("reading file")

f=filehandling("test.text")
f.readfile("test.txt")
del f