#default methods - built in method & userdefined methods-->method name,method body
#parameterizedmethods--
#it allows the same method to behave differently for diff inputs

class calculator:
    def add(self,a,b):
        print(a+b)

c=calculator()
c.add(9,7)

#default parameters
class test:
    def run(self,browser="chrome"):
        print("running in ",browser)
e=test()
e.run()
e.run("firefox")
#*args parameterized methods
class numbers:
    def total(self,*args):
        print(sum(args))
n=numbers()
n.total(8,9)
n.total(6,5)
