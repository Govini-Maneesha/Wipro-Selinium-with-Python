#variables = used to share the data
#instance variables-global variables at class level
#local variables- inside the method only

#instance variables example

class student:
    # CLAss variable
    school = "Sri chaithanya"

    def __init__(self,name,marks):
        #instance variable/global variable
        self.name=name
        self.marks=marks


    def show(self):
        schoolcity="Tirupati"  # local variable - scope is inside the method
        print(self.name,self.marks)
        print(self.school)
        print(schoolcity)

s1=student("Mani",99)
s2=student("Pavan",90)
s1.show()
s2.show()