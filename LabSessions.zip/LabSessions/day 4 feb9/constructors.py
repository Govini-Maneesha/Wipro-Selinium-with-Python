#constructors- first function of the class called when an object of the class is created
#syntax __init__()
#we can parameterized the constructors
#self is mandatory
#from curses.textpad import rectangle


class student:
    def __init__(self):
        print("constructor is called")
    def addsum(self):
        print("adding 2 nums")

s1=student()
s1.addsum()

#self.name is a instance variable or a global variable (belongs to object)
#name is a local parametar(exists inside the method)
#if we dont assign it to the self.name the object will not remember the value
class employee:
    def __init__(self,employeename,employeeid, employeedept):
        self.employeename = employeename
        self.employeeid = employeeid
        self.employeedept = employeedept

    def displayemployeedetails(self):
        print(self.employeename,self.employeeid,self.employeedept)
emp1=employee("Vinay",123,"webdevelopment")
emp2=employee("Jeeva",456,"Fullstack")
emp1.displayemployeedetails()
emp2.displayemployeedetails()

#using * args in constructor

class numbers:
    def __init__(self, *args):
        self.values = args
n=numbers(10,20,30)
print(n.values)
m=numbers(10,2)
print(m.values)
p=numbers(2)
print(p.values)


#super keyword for accesing parent constructor
#calling parent constructor(super())
class Parent:
    def __init__(self):
        super().__init__()
        print("i am the child constructor")
class child(Parent):
    def __init__(self):
        super().__init__()
        print("I am a child constructor")

c=child()

#prac1
class book():
    def __init__(self,title, author):
        self.title=title
        self.author=author

    def details(self):
        print(self.title, self.author)
auth1=book("Title: Meera talanted girl,","Author: Meearabai")
auth2=book("Title: Gardening Therapy,","Author: Vivek")
auth3=book("Title: Undercoverage ","Author: Deepak")

auth1.details()
auth2.details()
auth3.details()

class Rectangle():
    def __init__(self, length, width):
        self.length=length
        self.width=width
        self.area = length * width
        self.perimeter = 2 * (length + width)

    def data(self):
        print(self.length,self.width,self.area,self.perimeter)
rect=Rectangle(5,5)
rect.data()