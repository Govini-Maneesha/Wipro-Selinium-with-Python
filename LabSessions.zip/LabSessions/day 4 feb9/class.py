#class is a blue print or a template
#which describes the state/ behaviour of its object
#data is put in variables
#behaviour is put in function

class student:
    #data/properties
    studentname="Ravi"
    studentid=12345

    #self is uesed to access the attribute of the class we have defined
    #it is automatically loaded
    #self represents the instance of the class

    # create a function to access the data
    def displaystudentdetails(self):
        print(self.studentname)
        print(self.studentid)

#create object of the class file
a=student()
a.displaystudentdetails()

