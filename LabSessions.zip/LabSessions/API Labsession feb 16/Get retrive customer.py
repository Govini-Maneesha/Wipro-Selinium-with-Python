import requests

BASE_URL = "https://jsonplaceholder.typicode.com/users/1"

try:
    print("\n--- GET CUSTOMER ---")

    response = requests.get(BASE_URL)

    print("Status Code:", response.status_code)

    # VALIDATION 1 → STATUS CODE
    if response.status_code == 200:
        print("PASS: Status code = 200")

        data = response.json()

        # VALIDATION 2 → CORRECT DETAILS
        if "name" in data and "email" in data:
            print("PASS: Correct customer details returned")

        # VALIDATION 3 → EMAIL MATCH
        expected_email = "Sincere@april.biz"
        if data["email"] == expected_email:
            print("PASS: Email matches expected value")
        else:
            print("FAIL: Email mismatch")

    else:
        print("FAIL: Expected status code 200")

except Exception as e:
    print("Error:", e)