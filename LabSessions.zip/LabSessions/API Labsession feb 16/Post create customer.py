import requests

BASE_URL = "https://jsonplaceholder.typicode.com/users"

try:
    print("\n--- CREATE CUSTOMER ---")

    payload = {
        "name": "Maneesha",
        "email": "maneesha@gmail.com"
    }

    response = requests.post(BASE_URL, json=payload)

    print("Status Code:", response.status_code)

    if response.status_code != 201:
        print("FAIL: Expected 201")
        exit()

    data = response.json()

    customer_id = data["id"]
    print("PASS: Customer created with ID:", customer_id)

    with open("customer_id.txt", "w") as f:
        f.write(str(customer_id))

except Exception as e:
    print("Error:", e)