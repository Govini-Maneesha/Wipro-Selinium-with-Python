import pytest
@pytest.mark.usefixtures("openbrowser")
def test_login():
    print("Enter the username")
    print("Enter password")
    print("click on the login button")
@pytest.mark.usefixtures("closebrowser")
def test_logout():
    print("User is loggedout")
