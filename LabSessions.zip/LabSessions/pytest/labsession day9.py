#Write a test that is skipped because a feature is not implemented yet.

import pytest
def test_case1():
    print("Testcase is execetes")
@pytest.mark.skip(reason="Feature is not implemented yet")
def test_new_feature():
    assert False

def test_case2():
    print("Testcase is execetes")

def test_case3():
    print("Testcase is execetes")
@pytest.mark.skip
def openbrowser():
    print("opening the browser")

#write a test that runs only on Linux and skips on Windows.
import sys

@pytest.mark.skipif(sys.platform.startswith("win"), reason="Runs only on Linux")
def test_linux_only():
    assert True

#Write a test that checks an API health endpoint.
#If status code is not 200 → skip the test dynamically.
import pytest
import requests

def test_api_health():
    try:
        response = requests.get("https://example.com/health", timeout=5)
    except requests.exceptions.RequestException:
        pytest.skip("API not reachable")

    if response.status_code != 200:
        pytest.skip(f"API returned {response.status_code}")

    assert response.status_code == 200


#.Mark a failing test as xfail with reason: "Bug #123".

@pytest.mark.xfail(reason="Bug #123")
def test_known_bug():
    assert 1 == 2

#5.You have 5 parameterized cases.2 are known bugs.Mark only those 2 cases as xfail without marking entire test.

import pytest


def double_number(num):
    # Intentional bug: wrong logic for 3 and 4
    if num == 3:
        return 5   # should be 6
    if num == 4:
        return 7   # should be 8
    return num * 2


@pytest.mark.parametrize(
    "num, expected",
    [
        (1, 2),   # normal case
        (2, 4),   # normal case

        pytest.param(
            3, 6,
            marks=pytest.mark.xfail(reason="Bug #101 - incorrect logic for 3")
        ),

        pytest.param(
            4, 8,
            marks=pytest.mark.xfail(reason="Bug #102 - incorrect logic for 4")
        ),

        (5, 10),  # normal case
    ]
)
def test_double_number(num, expected):
    assert double_number(num) == expected