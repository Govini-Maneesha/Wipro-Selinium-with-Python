#grouping - set of testcases run together- issue fix in that module

import pytest
def test_case1():
    print("Testcase is execetes")
@pytest.mark.skip
def test_case2():
    print("Testcase is execetes")

def test_case3():
    print("Testcase is execetes")
@pytest.mark.skip
def openbrowser():
    print("opening the browser")