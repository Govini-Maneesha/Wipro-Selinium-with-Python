import pytest
from Test_SimpleFixture import api_url
def test_case1():
    print("Testcase1 is execetes")

def test_case2():
    print("Testcase2 is execetes")

def test_case3():
    print("Testcase3 is execetes")

import pytest
def test_case4():
    print("Testcase4 is execetes")

def test_case5():
    print("Testcase5 is execetes")

def test_login():
    print("Login test is execetes")

def test_api(api_url):
    assert "https" in api_url