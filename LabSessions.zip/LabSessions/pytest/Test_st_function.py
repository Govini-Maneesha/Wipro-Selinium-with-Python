def setup_function(function):
    print("opening the browser")

def teardown_function():
    print("closing the browser")

def test_case1():
    print("Testcase1 is execetes")

def test_case2():
    print("Testcase2 is execetes")

def test_case3():
    print("Testcase3 is execetes")

