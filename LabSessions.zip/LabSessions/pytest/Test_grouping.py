#to skip certain testcases that u already known as defected
import pytest

def setup_function(function):
    print("opening the browser")
    print("navigatin to home page")

def teardown_function(function):
    print("closing the browser")

@pytest.mark.sanity
def test_case1():
    print("Testcase is execetes")
@pytest.mark.regression
def test_case2():
    print("Testcase is execetes")

def test_case3():
    print("Testcase is execetes")

def openbrowser():
    print("opening the browser")