# used inside the class
# it will run for every class definition 0nce  it will run starting and  at ending of the class
class Testclass1:
    def setup_class(cls):
        print("API Authorization needed with username and password")
    def teardown_class(cls):
        print("API authorization closed")
    def setup_method(method):
        print("opening the browser")
    def teardown_method(meyhod):
        print("closing the browser")

    def test_case1(self):
        print("Testcase1 is execeted")
    def test_case2(self):
        print("Testcase2 is execeted")
    def test_case3(self):
        print("Testcase3 is execeted")

class Testclass2():

    def test_case1(self):
        print("Testcase1 is execeted")
    def test_case2(self):
        print("Testcase2 is execeted")
    def test_case3(self):
        print("Testcase3 is execeted")