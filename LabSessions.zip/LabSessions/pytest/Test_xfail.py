#xfail is a marker used to indicate that a test is expected to fail due to a known issue (e.g., a bug or an unimplemented feature)

import pytest
@pytest.mark.xfail(reason="Known bug in the third-party library")
def test_function_with_bug():
    assert (1+1)==3
@pytest.mark.sanity
def test_case1():
    print("Testcase is execetes")
@pytest.mark.regression
def test_case2():
    print("Testcase is execetes")

def test_case3():
    print("Testcase is execetes")
