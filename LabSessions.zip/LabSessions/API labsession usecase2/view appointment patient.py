#Patient views appointment (GET)
import os

print("\n--- VIEW APPOINTMENT ---")

# check appointment exists
if not os.path.exists("appointment_id.txt"):
    print("ERROR: Run book_appointment.py first")
    exit()

# read appointment id
with open("appointment_id.txt") as f:
    appointment_id = f.read().strip()

# simulate database
appointment_db = {
    "9001": {
        "patient_id": 101,
        "doctor_id": 501,
        "date": "2026-03-10",
        "time": "10:00",
        "status": "BOOKED"
    }
}

# simulate GET API
if appointment_id in appointment_db:
    print("Status Code: 200")
    print("PASS: Appointment details retrieved")

    data = appointment_db[appointment_id]
    print("Patient ID:", data["patient_id"])
    print("Doctor ID:", data["doctor_id"])
    print("Date:", data["date"])
    print("Time:", data["time"])
    print("Status:", data["status"])

else:
    print("Status Code: 404")
    print("FAIL: Appointment not found")