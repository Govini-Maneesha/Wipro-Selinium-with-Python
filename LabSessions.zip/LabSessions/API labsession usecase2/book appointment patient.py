#Patient books appointment (POST)
import requests

print("\n--- BOOK APPOINTMENT ---")

# pretend IDs came from previous APIs
patient_id = 101
doctor_id = 501

appointment_payload = {
    "patient_id": patient_id,
    "doctor_id": doctor_id,
    "date": "2026-03-10",
    "time": "10:00"
}

# simulate API call
response_status = 201
appointment_id = 9001

# validations
print("Status Code:", response_status)

if response_status == 201:
    print("PASS: Appointment created")
    print("Appointment ID:", appointment_id)

    # store for next step
    with open("appointment_id.txt", "w") as f:
        f.write(str(appointment_id))

else:
    print("FAIL: Appointment not created")