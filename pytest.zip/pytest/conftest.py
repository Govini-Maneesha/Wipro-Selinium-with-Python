
import pytest
@pytest.fixture
def simple_data():
    return 45


@pytest.fixture(params=["chrome", "firefox"])
def browser(request):
    print("Current browser:", request.param)
    return request.param

@pytest.fixture()
def api_url():
    return  "https://api.example.com"

@pytest.fixture(scope = 'function')
def openbrowser():
    # precondition
    print("open the browser")

@pytest.fixture(scope = 'function')
def closebrowser():
     # post condition
    print("closing the browser")

#class level

@pytest.fixture(scope="class")
def openbrowser():
    print("\n[SETUP] Open browser - CLASS LEVEL")

@pytest.fixture(scope="class")
def closebrowser():
    print("\n[TEARDOWN] Close browser - CLASS LEVEL")

#module level

@pytest.fixture(scope="module")
def openbrowser():
    print("\n[SETUP] Open browser - MODULE LEVEL")

@pytest.fixture(scope="module")
def closebrowser():
    print("\n[TEARDOWN] Close browser - MODULE LEVEL")

#sessionlevel


@pytest.fixture(scope="session")
def openbrowser():
    print("\n[SETUP] Open browser - SESSION LEVEL")

@pytest.fixture(scope="session")
def closebrowser():
    print("\n[TEARDOWN] Close browser - SESSION LEVEL")