#unit testing is type of testing done by the developers
# unit testing is type of testing done by the developers
# what component they have developed they do the testing for it before integrating it to the other modules
# get defects earlier
# Pytest in python , junit and nunit - java
# pytest is used ny developers and testers

#testcase1
import pytest
def test_case1():
    print("Testcase is execetes")

def test_case2():
    print("Testcase is execetes")

def test_case3():
    print("Testcase is execetes")

def openbrowser():
    print("opening the browser")